// 自定义文件
declare module '*.css';
declare module '*.scss';
declare module "*.png";
declare module "*.jpg";
declare module "*.svg";
